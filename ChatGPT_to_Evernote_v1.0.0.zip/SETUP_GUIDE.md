# ChatGPT to Evernote - セットアップガイド

## 📋 必要なもの
- Windows 10/11
- Google Chrome
- Evernoteアカウント

## 🚀 インストール手順

### 1. サーバーアプリケーションのセットアップ

1. `ChatGPT_to_Evernote`フォルダを任意の場所に配置
2. `.env.example`を`.env`にリネーム
3. `.env`ファイルを編集:
   ```
   # Evernote OAuth設定
   EVERNOTE_CONSUMER_KEY=あなたのConsumer Key
   EVERNOTE_CONSUMER_SECRET=あなたのConsumer Secret
   
   # OAuth認証を使用
   USE_OAUTH=true
   
   # 環境設定（本番: production, テスト: sandbox）
   EVERNOTE_ENVIRONMENT=production
   
   # ノートブック名
   EVERNOTE_NOTEBOOK_NAME=ChatGPT Logs
   ```

4. `ChatGPT_to_Evernote.exe`をダブルクリックして起動
5. **初回のみ**: コマンドプロンプトが開き、OAuth認証を求められます
   - ブラウザでEvernote認証ページが開きます
   - 「承認」をクリック
   - 表示されたコードをコピー
   - コマンドプロンプトに貼り付けてEnter
   - 「Evernote OAuth認証が完了しました」と表示されればOK

6. システムトレイ（タスクバー右下）にアイコンが表示されます

### 2. Chrome拡張機能のインストール

1. `ChatGPT_to_Evernote_Extension.zip`を解凍
2. Chromeで`chrome://extensions/`を開く
3. 右上の「デベロッパーモード」をON
4. 「パッケージ化されていない拡張機能を読み込む」をクリック
5. 解凍したフォルダ（`chrome-extension`）を選択
6. 拡張機能が追加されたら完了

## 💡 使い方

1. `ChatGPT_to_Evernote.exe`を起動（システムトレイに常駐）
2. ChatGPT (https://chatgpt.com/) で会話
3. 拡張機能のアイコンをクリック
4. 「この会話を保存」ボタンをクリック

**自動同期**: 1時間ごとに自動的に同期されます

## 🔧 トラブルシューティング

### サーバーに接続できない
- `ChatGPT_to_Evernote.exe`が起動しているか確認
- システムトレイにアイコンが表示されているか確認
- ファイアウォールで`localhost:8765`がブロックされていないか確認

### 会話データを取得できない
- ChatGPTのページをリロード（F5）
- 拡張機能を再読み込み（`chrome://extensions/`で🔄をクリック）

### OAuth認証エラー
1. `.env`ファイルの`EVERNOTE_CONSUMER_KEY`と`EVERNOTE_CONSUMER_SECRET`を確認
2. `.evernote_oauth_token`ファイルを削除
3. アプリケーションを再起動して再認証

### 「ノート作成に失敗しました」エラー
- Evernoteのノートブック「ChatGPT Logs」が存在するか確認
- 存在しない場合は自動作成されます

## 📝 注意事項

- **Consumer Key/Secret**: Evernote API Keyが必要です（無料取得可能）
  - https://dev.evernote.com/
- **プライバシー**: 会話データはローカルサーバー経由でEvernoteに直接送信されます
- **自動起動**: Windows起動時に自動起動したい場合は、EXEファイルのショートカットを`スタートアップ`フォルダに配置

## 🆘 サポート

問題が発生した場合:
1. `evernote_server.log`ファイルを確認
2. システムトレイアイコンを右クリック → 「ログを開く」
3. GitHubリポジトリでIssueを作成

---

**Version**: 1.0.0  
**Repository**: https://github.com/ozaki-taisuke/chatgpt-to-evernote
